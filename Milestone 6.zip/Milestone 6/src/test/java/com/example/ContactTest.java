package com.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("12345", "Coden", "Polk", "1234567890", "123 Main Street");
        assertEquals("12345", contact.getContactId());
        assertEquals("Coden", contact.getFirstName());
        assertEquals("Polk", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    public void testInvalidContactIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Coden", "Polk", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testInvalidContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Coden", "Polk", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testInvalidFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Polk", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testInvalidFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "LongFirstName", "Polk", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testInvalidLastNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Coden", null, "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testInvalidLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Coden", "VeryLongLastName", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testInvalidPhoneNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Coden", "Polk", null, "123 Main Street");
        });
    }

    @Test
    public void testInvalidPhoneWrongLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Coden", "Polk", "12345", "123 Main Street");
        });
    }

    @Test
    public void testInvalidPhoneNonDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Coden", "Polk", "12345abcde", "123 Main Street");
        });
    }

    @Test
    public void testInvalidAddressNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Coden", "Polk", "1234567890", null);
        });
    }

    @Test
    public void testInvalidAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Coden", "Polk", "1234567890",
                    "1234567890123456789012345678901");
        });
    }

    @Test
    public void testSetFirstName() {
        Contact contact = new Contact("12345", "Coden", "Polk", "1234567890", "123 Main Street");
        contact.setFirstName("Daniel");
        assertEquals("Daniel", contact.getFirstName());
    }

    @Test
    public void testSetLastName() {
        Contact contact = new Contact("12345", "Coden", "Polk", "1234567890", "123 Main Street");
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    public void testSetPhone() {
        Contact contact = new Contact("12345", "Coden", "Polk", "1234567890", "123 Main Street");
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    public void testSetAddress() {
        Contact contact = new Contact("12345", "Coden", "Polk", "1234567890", "123 Main Street");
        contact.setAddress("456 Oak Avenue");
        assertEquals("456 Oak Avenue", contact.getAddress());
    }
}