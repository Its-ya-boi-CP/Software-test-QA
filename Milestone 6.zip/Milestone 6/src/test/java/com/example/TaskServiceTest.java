package com.example;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService service;

    @BeforeEach
    public void setUp() {
        service = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("T001", "Task One", "First task");
        service.addTask(task);

        assertNotNull(service.getTask("T001"));
        assertEquals("Task One", service.getTask("T001").getName());
    }

    @Test
    public void testAddTaskWithDuplicateIdThrowsException() {
        Task task1 = new Task("T001", "Task One", "First task");
        Task task2 = new Task("T001", "Task Two", "Second task");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("T001", "Task One", "First task");
        service.addTask(task);
        service.deleteTask("T001");

        assertNull(service.getTask("T001"));
    }

    @Test
    public void testDeleteNonexistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("BADID");
        });
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("T001", "Old Name", "First task");
        service.addTask(task);

        service.updateTaskName("T001", "New Name");

        assertEquals("New Name", service.getTask("T001").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("T001", "Task One", "Old description");
        service.addTask(task);

        service.updateTaskDescription("T001", "New description");

        assertEquals("New description", service.getTask("T001").getDescription());
    }

    @Test
    public void testUpdateNonexistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskName("BADID", "New Name");
        });
    }
}