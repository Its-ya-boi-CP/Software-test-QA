package com.example;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
    private AppointmentService service;

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86_400_000L);
    }

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
    }

    @Test
    public void testAddAppointment() {
        Date date = futureDate();
        service.addAppointment("A123", date, "Dentist appointment");

        Appointment savedAppointment = service.getAppointment("A123");

        assertNotNull(savedAppointment);
        assertEquals("A123", savedAppointment.getAppointmentId());
        assertEquals(date, savedAppointment.getAppointmentDate());
        assertEquals("Dentist appointment", savedAppointment.getDescription());
    }

    @Test
    public void testAddAppointmentWithDuplicateIdThrowsException() {
        Date date = futureDate();
        service.addAppointment("A123", date, "Dentist appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("A123", futureDate(), "Another appointment");
        });
    }

    @Test
    public void testDeleteAppointment() {
        service.addAppointment("A123", futureDate(), "Dentist appointment");

        service.deleteAppointment("A123");

        assertNull(service.getAppointment("A123"));
    }

    @Test
    public void testUpdateAppointmentDate() {
        service.addAppointment("A123", futureDate(), "Dentist appointment");
        Date updatedDate = new Date(System.currentTimeMillis() + 172_800_000L);

        service.updateAppointmentDate("A123", updatedDate);

        assertEquals(updatedDate, service.getAppointment("A123").getAppointmentDate());
    }

    @Test
    public void testUpdateAppointmentDescription() {
        service.addAppointment("A123", futureDate(), "Dentist appointment");

        service.updateAppointmentDescription("A123", "Updated description");

        assertEquals("Updated description", service.getAppointment("A123").getDescription());
    }
}