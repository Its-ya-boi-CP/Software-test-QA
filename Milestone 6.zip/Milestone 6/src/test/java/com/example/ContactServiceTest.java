package com.example;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1001", "Coden", "Polk", "1234567890", "123 Main Street");

        service.addContact(contact);

        assertEquals(contact, service.getContactById("1001"));
    }

    @Test
    public void testAddDuplicateContactId() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("1001", "Coden", "Polk", "1234567890", "123 Main Street");
        Contact contact2 = new Contact("1001", "Daniel", "Smith", "0987654321", "456 Oak Avenue");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1001", "Coden", "Polk", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.deleteContact("1001");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getContactById("1001");
        });
    }

    @Test
    public void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1001", "Coden", "Polk", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updateFirstName("1001", "Daniel");

        assertEquals("Daniel", service.getContactById("1001").getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1001", "Coden", "Polk", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updateLastName("1001", "Smith");

        assertEquals("Smith", service.getContactById("1001").getLastName());
    }

    @Test
    public void testUpdatePhone() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1001", "Coden", "Polk", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updatePhone("1001", "0987654321");

        assertEquals("0987654321", service.getContactById("1001").getPhone());
    }

    @Test
    public void testUpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1001", "Coden", "Polk", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updateAddress("1001", "456 Oak Avenue");

        assertEquals("456 Oak Avenue", service.getContactById("1001").getAddress());
    }

    @Test
    public void testUpdateNonexistentContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("9999", "Daniel");
        });
    }
}