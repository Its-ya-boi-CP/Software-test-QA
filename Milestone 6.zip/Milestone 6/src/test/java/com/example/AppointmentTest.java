package com.example;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 86_400_000L);
    }

    private Date pastDate() {
        return new Date(System.currentTimeMillis() - 86_400_000L);
    }

    @Test
    public void testValidAppointmentCreation() {
        Date date = futureDate();
        Appointment appointment = new Appointment("A123", date, "Doctor visit");

        assertEquals("A123", appointment.getAppointmentId());
        assertEquals(date, appointment.getAppointmentDate());
        assertEquals("Doctor visit", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate(), "Doctor visit");
        });
    }

    @Test
    public void testAppointmentIdCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate(), "Doctor visit");
        });
    }

    @Test
    public void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", null, "Doctor visit");
        });
    }

    @Test
    public void testAppointmentDateCannotBeInPast() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", pastDate(), "Doctor visit");
        });
    }

    @Test
    public void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", futureDate(), null);
        });
    }

    @Test
    public void testDescriptionCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("A123", futureDate(),
                    "This description is definitely longer than fifty characters total.");
        });
    }

    @Test
    public void testSetAppointmentDate() {
        Appointment appointment = new Appointment("A123", futureDate(), "Doctor visit");
        Date updatedDate = new Date(System.currentTimeMillis() + 172_800_000L);

        appointment.setAppointmentDate(updatedDate);

        assertEquals(updatedDate, appointment.getAppointmentDate());
    }

    @Test
    public void testSetAppointmentDateCannotBeNull() {
        Appointment appointment = new Appointment("A123", futureDate(), "Doctor visit");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(null);
        });
    }

    @Test
    public void testSetAppointmentDateCannotBePast() {
        Appointment appointment = new Appointment("A123", futureDate(), "Doctor visit");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(pastDate());
        });
    }

    @Test
    public void testSetDescription() {
        Appointment appointment = new Appointment("A123", futureDate(), "Doctor visit");

        appointment.setDescription("Updated appointment");

        assertEquals("Updated appointment", appointment.getDescription());
    }

    @Test
    public void testSetDescriptionCannotBeNull() {
        Appointment appointment = new Appointment("A123", futureDate(), "Doctor visit");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(null);
        });
    }

    @Test
    public void testSetDescriptionCannotBeTooLong() {
        Appointment appointment = new Appointment("A123", futureDate(), "Doctor visit");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription("This description is definitely longer than fifty characters total.");
        });
    }
}